package com.ilp.dao;

import com.ilp.model.Login;
import com.ilp.model.User;

public interface UserDao {

  void register(User user);

  User validateUser(Login login);
}