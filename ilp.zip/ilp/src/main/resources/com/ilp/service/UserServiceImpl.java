package com.ilp.service;

import com.ilp.model.Login;
import com.ilp.model.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ilp.dao.userDao;

@Service
public class UserServiceImpl implements UserService {
  @Autowiredd
  public UserDao userDao;
    public void register(User user) {
        userDao.register(user);
    }
    public void validateUser(Login login) {
        userDao.validateUser(login);
    }
}
