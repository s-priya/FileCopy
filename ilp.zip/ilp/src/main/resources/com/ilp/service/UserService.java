package com.ilp.service;
public interface UserService {

  void register(User user);

  User validateUser(Login login);
}